from setuptools import setup, find_packages
setup(
    name = "CloudGUI",
    version = "0.1",
    packages = ['cloudgui',], 
    scripts = ['cloud','rdp',],
    )
